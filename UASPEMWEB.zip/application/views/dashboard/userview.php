
    <main role="main" class="col-md-9 ml-sm-auto col-lg-10 px-4">

    </form>

      <div class="d-flex justify-content-between flex-wrap flex-md-nowrap align-items-center pt-3 pb-2 mb-3 border-bottom">
        <h1 class="h2">USERS</h1>
      </div>

      <div class="table-responsive">
        <table class="table table-striped table-sm">
          <thead>
            <tr>
              <th>Username</th>
              <th>Full Name</th>
              <th>Password</th>
              <th>Action</th>
            </tr>
          </thead>
          <tbody>
            <?php 
            // menampilkan data buku
            foreach ($users as $users_item): 

            ?>
            <tr>
              <td><?php echo $users_item['username']?></td>
              <td><?php echo $users_item['fullname']?></td>
              <td><?php echo $users_item['password']?></td>
              <td><?php echo anchor('users/viewedit/'.$users_item['username'], 'Edit', 'Edit User'); ?> | <?php echo anchor('users/delete/'.$users_item['username'], 'Del', 'Hapus User'); ?></td>
            </tr>
            <?php endforeach; ?>
             <p><?php echo anchor('users/inputuser', 'Add new User','class="btn btn-outline btn-primary btn-lg"'); ?></p>
          </tbody>
        </table>
      </div>
    </main>
  