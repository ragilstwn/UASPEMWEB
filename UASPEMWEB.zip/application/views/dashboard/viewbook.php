
    <main role="main" class="col-md-9 ml-sm-auto col-lg-10 px-4">

  
    <div class="d-flex justify-content-between flex-wrap flex-md-nowrap align-items-center pt-3 pb-2 mb-3 border-bottom">
        <h1 class="h2">Detail Buku </h1>
      </div>

      <div class="table-responsive">
        <table class="table table-striped table-sm">
          <tbody>
            <tr style="background: transparent;">
            <td colspan="4";><center>
              <div style="width: 212px; height: 300px; ">
                <img style="max-width: 100%; max-height: 100%;" src=<?php echo base_url('assets/images/'.$book[0]['imgfile']);  ?>></img>
              </div>
            </center></td>
            </tr><tr style="background: transparent; border: none;">
             <td style="width:50px;">
               
             </td>
             <td style="width:150px;"><div style="font-size: 20px" class="form-group">Judul</div></td>
              <td><div style="font-size: 20px" class="form-group"><?php echo $book[0]['judul']?></div></td>
              <td>
               
             </td>
            </tr>
            <tr style="background: transparent; border: none;">
              <td style="width:300px;">
               
             </td>
              <td style="width:300px;"><div style="font-size: 20px" class="form-group">Pengarang</div></td>
              <td><div style="font-size: 20px" class="form-group"><?php echo $book[0]['pengarang']?></div></td>
              <td>
               
             </td>
            </tr>
            <tr style="background: transparent; border-color: none;">
              <td style="width:300px;">
               
             </td>
              <td style="width:300px;"><div style="font-size: 20px" class="form-group">Penerbit</div></td>
              <td><div style="font-size: 20px" class="form-group"><?php echo $book[0]['penerbit']?></div></td>
              <td>
               
             </td>
            </tr>
            <tr style="background: transparent;">
              <td style="width:300px;">
               
             </td>
              <td style="width:300px;"><div style="font-size: 20px" class="form-group">Tahun Terbit</div></td>
              <td><div style="font-size: 20px" class="form-group"><?php echo $book[0]['thnterbit']?></div></td>
              <td>
               
             </td>
            </tr>
            <tr style="background: transparent;">
              <td style="width:300px;">
               
             </td>
              <td style="width:300px;"><div style="font-size: 20px" class="form-group">Sinopsis</div></td>
              <td><div style="font-size: 20px" class="form-group"><?php echo $book[0]['sinopsis']?></div></td>
              <td>
               
             </td>
            </tr>
          </tbody>
        </table>
      </div>
    </main>
  