<?php

class User_model extends CI_Model {

	// method untuk membaca data profile user berdasar username
	public function getUserProfile($username){
		$query = $this->db->get_where('users', array('username' => $username));
		return $query->row_array();
	}


	// method untuk menampilkan user
	public function showuser($id = false){
		// membaca semua user dari tabel 'users'
		if ($id == false){
			$query = $this->db->get('users');
			return $query->result_array();
		} else {
			// membaca data buku berdasarkan id
			$query = $this->db->get_where('users', array("username" => $id));
			return $query->row_array();
		}
	}

	public function inputusers($id = false){
		// membaca semua user dari tabel 'users'
		if ($id == false){
			$query = $this->db->get('users');
			return $query->result_array();
		} else {
			// membaca data buku berdasarkan id
			$query = $this->db->get_where('users', array("username" => $id));
			return $query->row_array();
		}
	}

	// method untuk hapus user berdasarkan premarykey
	public function deluser($id){
		$this->db->delete('users', array("username" => $id));
	}


	// method untuk insert user ke tabel 'user'
	public function insertuser($username, $password, $fullname, $role){
		$data = array(
					"username" => $username,
					"password" => $password,
					"fullname" => $fullname,
					"role" =>$role
		);
		$query = $this->db->insert('users', $data);
	}

	// method untuk membaca data kategori buku dari tabel 'kategori'
	public function getuser(){
		$query = $this->db->get('users');
		return $query->result_array();
	}
	public function update($username, $fullname, $password, $role, $oldusername){
		$data = array(
				'username' => $username,
				'fullname' => $fullname,
				'password' => $password,
				'role' => $role
			);
			$this->db->where('username',$oldusername);
			$this->db->update('users',$data);
			redirect('users/userview');
	}
	public function getUserSpecific($username){
		$this->db->where('username',$username);
		$query = $this->db->get('users');
		return $query->result_array();
	}

	
}

?>