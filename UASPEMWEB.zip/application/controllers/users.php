<?php
class users extends CI_Controller {

	public function __construct(){
		parent::__construct();
		 $this->load->model('user_model');
         $this->load->helper('url_helper');
		
		// cek keberadaan session 'username'	
		if (!isset($_SESSION['username'])){
			// jika session 'username' blm ada, maka arahkan ke kontroller 'login'
			redirect('login');
		}
	}
  // method untuk menampilkan seluruh data kategori
        public function userview(){
            // panggil method showBook() dari book_model untuk membaca seluruh data buku
            $data['users'] = $this->user_model->showuser();

            $data['fullname'] = $_SESSION['fullname'];

            // tampilkan view 'dashboard/books'
            $this->load->view('dashboard/header', $data);
            $this->load->view('dashboard/userview', $data);
            $this->load->view('dashboard/footer', $data);
        } 

          public function inputuser(){
            // panggil method showBook() dari book_model untuk membaca seluruh data buku
            $data['users'] = $this->user_model->inputusers();

            $data['fullname'] = $_SESSION['fullname'];

            // tampilkan view 'dashboard/books'
            $this->load->view('dashboard/header', $data);
            $this->load->view('dashboard/inputuser', $data);
            $this->load->view('dashboard/footer', $data);
        } 

	// method hapus data buku berdasarkan id
	public function delete($id){
		$this->user_model->deluser($id);
		// arahkan ke method 'books' di kontroller 'dashboard'
		redirect('users/userview');
	}

	// method untuk tambah data buku
	public function insert(){

		// baca data dari form user
		$username = $_POST['username'];
		$fullname = $_POST['fullname'];
		$password = $_POST['password'];
		$role = $_POST['role'];
		

		// panggil method insertBook() di model 'book_model' untuk menjalankan query insert
		$this->user_model->insertuser($username,  $password, $fullname,$role );

		// arahkan ke method 'books' di kontroller 'dashboard'
		redirect('users/userview');
	}

	// method untuk edit data buku berdasarkan id
	public function edit($oldusername){
			$data['fullname'] = $_SESSION['fullname'];
			$username = $_POST['username'];
			$fullname = $_POST['fullname'];
			$password = $_POST['password'];
			$role = $_POST['role'];
			$this->user_model->update($username, $fullname, $password, $role, $oldusername);

	}
	public function viewedit($username){
			$data['fullname'] = $_SESSION['fullname'];
			$data['users'] = $this->user_model->getUserSpecific($username);

            $this->load->view('dashboard/header', $data);
            $this->load->view('dashboard/edituser', $data);
            $this->load->view('dashboard/footer', $data);
        }

	// method untuk update data buku berdasarkan id

	    
	}
?>