###################
Books Project
###################

Books Project digunakan sebagai sample project untuk keperluan perkuliahan di Pendidikan TIK FKIP Universitas Sebelas Maret. Books Project merupakan Web-based Project Application yang dibuat menggunakan Codeigniter PHP Framework.

Aplikasi ini secara umum digunakan untuk keperluan CRUD data buku.
